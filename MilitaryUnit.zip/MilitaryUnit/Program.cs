﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryUnit
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
    class Personnel
    {
        public enum Company { Alpha, Bravo, Charlie, Weapons }
        public enum Rank { PVT, PFC, LCPL, CPL, SGT, SSGT, GSGT, MSTSGT, SGTMAJ }

        protected string name;
        protected Rank CurrentRank;
        protected Company AssignedCompany;

        public int HP;
        
        public virtual void TakeAction()
        {
            Console.WriteLine("Start shooting!");
        }

        public virtual void Run()
        {
            Console.WriteLine("Run quickly!");
        }
    }

    class Pog : Personnel
    {
        public Pog(Rank CurrentRank, string name, Company AssignedCompany)
        {
            this.CurrentRank = CurrentRank;
            this.name = name;
            this.AssignedCompany = AssignedCompany;
            HP = 50;
        }
        public override void TakeAction()
        {
            Console.WriteLine("File paperwork!");
        }
        public override void Run()
        {
            Console.WriteLine("Run Slowly!");
        }
    }
    class Grunt : Personnel
    {
        public Grunt(Rank CurrentRank, string name, Company AssignedCompany)
        {
            this.CurrentRank = CurrentRank;
            this.name = name;
            this.AssignedCompany = AssignedCompany;
            HP = 250;
        }
    }

    class Weapon
    {
        public enum Caliber { BigBoom, LittleBoom }
        
        protected int rangeInMeters;
        protected Caliber Cal;
        protected int magCapacity;

        public bool IsLoaded;
        public int RoundCount;
        public bool Shoot;

        public void Fire()
        {
            if (Shoot == true)
            {
                RoundCount++;
            }
            if (RoundCount == magCapacity)
            {
                IsLoaded = false;
            }
        }
        public virtual void Sound()
        {
            Console.WriteLine("BOOM!");
        }
    }

    class SniperRifle : Weapon
    {
        public SniperRifle(bool IsLoaded, int RoundCount)
        {
            this.IsLoaded = IsLoaded;
            this.RoundCount = RoundCount;
            Cal = Caliber.LittleBoom;
            magCapacity = 10;
            rangeInMeters = 1000;
        }
        public override void Sound()
        {
            Console.WriteLine("Pfft!");
        }
    }

    class GranadeLauncher : Weapon
    {
        public GranadeLauncher(bool IsLoaded, int RoundCount)
        {
            this.IsLoaded = IsLoaded;
            this.RoundCount = RoundCount;
            Cal = Caliber.BigBoom;
            magCapacity = 1;
            rangeInMeters = 150;
        }
    }

    class Saw : Weapon
    {
        public Saw(bool IsLoaded, int RoundCount)
        {
            this.IsLoaded = IsLoaded;
            this.RoundCount = RoundCount;
            Cal = Caliber.LittleBoom;
            magCapacity = 75;
            rangeInMeters = 600;
        }
    }

    public class MissionUnpossible
    {
       

    }
        
}
